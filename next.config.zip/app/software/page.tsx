import Index from "@/app/src/modules/softwarePage"


const Page = () => {
  return (
    <>
    <Index />
    </>
  )
}

export default Page