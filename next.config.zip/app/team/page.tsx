import TeamPage from '@/app/src/modules/teamPage/team'
import React from 'react'

const Page = () => {
  return (
    <>
    <TeamPage />
    </>
  )
}

export default Page;