import ContactSection from '@/app/src/modules/contactPage/contact'
import React from 'react'

const Page = () => {
  return (
    <>
    <ContactSection />
    </>
  )
}

export default Page