"use client";

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Code, Server, Cpu, Sparkles, ChevronRight, Users, Award, Clock, CheckCircle } from 'lucide-react';

interface GetStartedProps {
  isDarkMode?: boolean;
}

export default function GetStarted({ isDarkMode = false }: GetStartedProps) {
  const [darkMode, setDarkMode] = useState(isDarkMode);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  // Sync with parent component
  useEffect(() => {
    setDarkMode(isDarkMode);
  }, [isDarkMode]);

  // Mouse move effect for subtle parallax
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth - 0.5) * 30,
        y: (e.clientY / window.innerHeight - 0.5) * 30,
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 80,
        damping: 15,
      },
    },
  };

  const floatingAnimation = {
    animate: {
      y: [0, -15, 0],
      transition: {
        duration: 3,
        repeat: Infinity,
        ease: "easeInOut",
      },
    },
  };

  return (
    <div className={`relative overflow-hidden transition-colors duration-500 ${
      darkMode ? 'bg-gray-900' : 'bg-white'
    }`}>
      {/* Main Content - Compact Design */}
      <div className="relative z-10 px-4 sm:px-6 lg:px-8 py-16 md:py-24 lg:py-32">
        <div className="max-w-7xl mx-auto">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="text-center"
            style={{
              transform: `translate(${mousePosition.x * 0.1}px, ${mousePosition.y * 0.1}px)`,
            }}
          >
            {/* Animated Title */}
            <div className="relative inline-block mb-8">
              <motion.h1
                variants={itemVariants}
                className={`text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold tracking-tight ${
                  darkMode ? 'text-white' : 'text-gray-900'
                }`}
              >
                Ready to
                <span className={`block ${darkMode ? 'text-red-400' : 'text-red-500'}`}>
                  Get Started?
                </span>
              </motion.h1>
              
              <motion.div
                className="absolute -bottom-3 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent"
                initial={{ width: 0 }}
                animate={{ width: '100%' }}
                transition={{ delay: 0.8, duration: 1.2, ease: "easeOut" }}
              />
            </div>

            {/* Subtitle */}
            <motion.p
              variants={itemVariants}
              className={`text-lg sm:text-xl lg:text-2xl mb-10 max-w-3xl mx-auto px-4 ${
                darkMode ? 'text-gray-300' : 'text-gray-700'
              }`}
            >
              Let's discuss your project and create a custom solution tailored to your needs.
              <motion.span
                animate={{ scale: [1, 1.3, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="inline-block ml-2"
              >
                🚀
              </motion.span>
            </motion.p>

            {/* Tech Stack Badges */}
            <motion.div
              variants={itemVariants}
              className="flex flex-wrap justify-center gap-3 mb-12 px-4"
            >
              {[
                { icon: Code, label: 'Frontend Development' },
                { icon: Server, label: 'Backend Systems' },
                { icon: Cpu, label: 'AI Integration' },
                { icon: Sparkles, label: 'Innovation' },
              ].map((tech, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.08, y: -3 }}
                  whileTap={{ scale: 0.95 }}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl border ${
                    darkMode 
                      ? 'border-gray-700 bg-gray-800/40 hover:bg-gray-800/70 text-gray-200' 
                      : 'border-gray-200 bg-gray-50 hover:bg-gray-100 text-gray-800'
                  } transition-all duration-300 shadow-sm hover:shadow-md`}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 1 + index * 0.1 }}
                >
                  <tech.icon className={`w-5 h-5 ${darkMode ? 'text-red-400' : 'text-red-500'}`} />
                  <span className="text-sm font-semibold whitespace-nowrap">{tech.label}</span>
                </motion.div>
              ))}
            </motion.div>

            {/* Action Buttons */}
            <motion.div
              variants={itemVariants}
              className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16"
            >
              <motion.button
                whileHover={{ 
                  scale: 1.05, 
                  boxShadow: darkMode 
                    ? "0 10px 30px rgba(239, 68, 68, 0.3)" 
                    : "0 10px 30px rgba(239, 68, 68, 0.25)" 
                }}
                whileTap={{ scale: 0.98 }}
                animate={floatingAnimation.animate}
                className={`group relative px-8 py-4 rounded-xl font-bold text-lg ${
                  darkMode 
                    ? 'bg-red-500 hover:bg-red-600 text-white' 
                    : 'bg-red-500 hover:bg-red-600 text-white'
                } transition-all duration-300 shadow-lg min-w-[220px]`}
              >
                <span className="relative z-10 flex items-center justify-center gap-3">
                  Start Your Project
                  <motion.span
                    animate={{ x: [0, 5, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    <ArrowRight className="w-5 h-5" />
                  </motion.span>
                </span>
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-red-600 via-red-500 to-red-400 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  initial={false}
                />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
                className={`group px-8 py-4 rounded-xl font-bold text-lg border-2 ${
                  darkMode 
                    ? 'border-red-400 text-red-400 hover:bg-red-400/10' 
                    : 'border-red-500 text-red-500 hover:bg-red-500/10'
                } transition-all duration-300 backdrop-blur-sm min-w-[220px]`}
              >
                <span className="flex items-center justify-center gap-3">
                  Schedule Consultation
                  <motion.span
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 0.5 }}
                    className={darkMode ? 'text-red-400' : 'text-red-500'}
                  >
                    <ChevronRight className="w-5 h-5" />
                  </motion.span>
                </span>
              </motion.button>
            </motion.div>

            {/* Stats Section - Compact */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2 }}
              className={`mt-12 pt-8 border-t ${
                darkMode ? 'border-gray-800' : 'border-gray-200'
              }`}
            >
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
                {[
                  { icon: Users, value: '100+', label: 'Happy Clients', color: 'text-blue-500' },
                  { icon: Award, value: '50+', label: 'Projects', color: 'text-green-500' },
                  { icon: Clock, value: '24/7', label: 'Support', color: 'text-purple-500' },
                  { icon: CheckCircle, value: '99%', label: 'Satisfaction', color: 'text-yellow-500' },
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.05 }}
                    className="text-center"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.4 + index * 0.1 }}
                  >
                    <div className="flex justify-center mb-2">
                      <stat.icon className={`w-8 h-8 ${stat.color}`} />
                    </div>
                    <div className={`text-3xl font-bold mb-1 ${
                      darkMode ? 'text-white' : 'text-gray-900'
                    }`}>
                      {stat.value}
                    </div>
                    <div className={`text-xs uppercase tracking-wider ${
                      darkMode ? 'text-gray-400' : 'text-gray-600'
                    }`}>
                      {stat.label}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

     

    </div>
  );
}