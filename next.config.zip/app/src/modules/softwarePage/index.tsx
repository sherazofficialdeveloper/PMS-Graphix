import ServicesSection from "./featuredService"
import GetStarted from "./getStarted"
import ProcessSection from "./ourProcess"
import SoftwareServices from "./ourSoftwareServices"
import CompactTechnologiesHero from "./technologies"


const Index = () => {
  return (
    <>
    <ServicesSection />
    <SoftwareServices />
    <ProcessSection />
    <CompactTechnologiesHero />
    <GetStarted />
    </>
  )
}

export default Index