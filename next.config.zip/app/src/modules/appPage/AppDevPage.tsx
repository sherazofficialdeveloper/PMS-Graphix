"use client"
import React, { useState, useEffect } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { 
  Smartphone, 
  Zap, 
  ShieldCheck, 
  Cloud, 
  ArrowRight,
  Monitor,
  Cpu,
  RefreshCw,
  Layout,
  Layers,
  Sparkles,
  Rocket,
  Moon,
  Sun,
  CheckCircle,
  Users,
  Clock,
  TrendingUp,
  Target,
  Palette,
  Code,
  Bug,
  Upload
} from 'lucide-react';

const AppDevPage: React.FC = () => {
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const { scrollY } = useScroll();
  const progressWidth = useTransform(scrollY, [0, 3000], ["0%", "100%"]);

  const processSteps = [
    {
      number: "1",
      title: "Rapid Prototyping",
      description: "Analyzing user personas and competitor apps to find your unique value proposition.",
      icon: <Target className="w-6 h-6" />
    },
    {
      number: "2",
      title: "Real Storyboarding",
      description: "Mapping every tap, swipe, and transition to ensure a frictionless journey.",
      icon: <Palette className="w-6 h-6" />
    },
    {
      number: "3",
      title: "Parallel Development",
      description: "Front-end and back-end engineers working in sync using agile sprints.",
      icon: <Code className="w-6 h-6" />
    },
    {
      number: "4",
      title: "Automated QA",
      description: "Stress-testing on over 50 different device types and OS versions.",
      icon: <Bug className="w-6 h-6" />
    },
    {
      number: "5",
      title: "Launch Strategy",
      description: "App Store Optimization (ASO) and deployment management for a viral debut.",
      icon: <Upload className="w-6 h-6" />
    }
  ];

  const features = [
    {
      number: "1",
      title: "Native Speed",
      description: "Optimized Swift, Kotlin, and C++ for milliseconds-perfect responsiveness.",
      icon: <Zap className="w-6 h-6" />
    },
    {
      number: "2",
      title: "Serverless Sync",
      description: "Real-time data synchronization across devices using modern cloud architectures.",
      icon: <Cloud className="w-6 h-6" />
    },
    {
      number: "3",
      title: "Biometric Auth",
      description: "Seamless FaceID, Fingerprint, and OAuth 2.0 security integrations.",
      icon: <ShieldCheck className="w-6 h-6" />
    },
    {
      number: "4",
      title: "Live Updates",
      description: "Over-the-air (OTA) updates to fix bugs instantly without app store delays.",
      icon: <RefreshCw className="w-6 h-6" />
    },
    {
      number: "5",
      title: "Cross-Platform",
      description: "Write once, run anywhere with high-fidelity React Native & Flutter code.",
      icon: <Monitor className="w-6 h-6" />
    },
    {
      number: "6",
      title: "Modular SDKs",
      description: "Custom software kits to scale your app's functionality effortlessly.",
      icon: <Layers className="w-6 h-6" />
    }
  ];

  const stats = [
    { value: "99%", label: "Client Satisfaction", icon: <CheckCircle className="w-8 h-8" /> },
    { value: "250+", label: "Projects Delivered", icon: <Rocket className="w-8 h-8" /> },
    { value: "50+", label: "Team Members", icon: <Users className="w-8 h-8" /> },
    { value: "24/7", label: "Support", icon: <Clock className="w-8 h-8" /> },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }}
      className={`${darkMode ? 'dark' : ''} min-h-screen overflow-hidden relative bg-gray-50 dark:bg-gray-950`}
    >
      {/* Theme Toggle */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setDarkMode(!darkMode)}
        className="fixed top-6 right-6 z-50 w-12 h-12 rounded-full bg-white dark:bg-gray-900 shadow-xl flex items-center justify-center border border-gray-200 dark:border-gray-800"
      >
        <AnimatePresence mode="wait">
          {darkMode ? (
            <motion.div
              key="sun"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
            >
              <Sun className="w-6 h-6 text-yellow-500" />
            </motion.div>
          ) : (
            <motion.div
              key="moon"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
            >
              <Moon className="w-6 h-6 text-gray-700" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Hero Section */}
      <section className="pt-32 pb-20 md:pb-48 relative">
        <div className="container mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-red-500/20 to-rose-500/20 text-red-600 dark:text-red-400 text-sm font-bold border border-red-500/30 uppercase tracking-widest backdrop-blur-sm"
              >
                <Sparkles className="mr-2 w-4 h-4" />
                Next-Gen Mobile Engineering
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tight leading-[1.1]"
              >
                Apps that <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-500 to-orange-500">
                  Ignite Passion.
                </span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-xl text-gray-600 dark:text-gray-300 max-w-xl leading-relaxed"
              >
                We craft blazing-fast mobile experiences with cutting-edge technology and pixel-perfect design.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="flex flex-wrap gap-4"
              >
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-gradient-to-r from-red-600 to-rose-600 text-white rounded-xl font-bold text-lg flex items-center gap-3 shadow-lg shadow-red-500/30 relative overflow-hidden group"
                >
                  <span className="relative z-10">Start Building</span>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-white dark:bg-gray-900 border-2 border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 rounded-xl font-bold text-lg hover:bg-red-50 dark:hover:bg-red-950/20 transition-colors"
                >
                  View Portfolio
                </motion.button>
              </motion.div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="relative flex justify-center"
            >
              <div className="relative w-72 h-[560px]">
                <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 via-transparent to-rose-500/20 rounded-[3rem] backdrop-blur-sm border-[12px] border-gray-900 shadow-2xl">
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-gray-900 rounded-b-2xl z-10"></div>
                  
                  <div className="w-full h-full bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-[2.2rem] overflow-hidden relative">
                    <div className="p-6 space-y-6">
                      <div className="w-full h-32 rounded-2xl bg-gradient-to-r from-red-500/20 to-rose-500/20 flex items-center justify-center">
                        <Rocket className="w-12 h-12 text-red-400" />
                      </div>
                      
                      <div className="space-y-4">
                        {[1, 2, 3].map((i) => (
                          <div
                            key={i}
                            className="h-3 bg-gradient-to-r from-red-500/30 to-rose-500/30 rounded-full"
                            style={{ width: `${[75, 100, 50][i-1]}%` }}
                          />
                        ))}
                      </div>
                      
                      <div className="flex justify-center gap-4 pt-8">
                        {[1, 2, 3].map((i) => (
                          <div
                            key={i}
                            className="w-12 h-12 rounded-full bg-gradient-to-r from-red-500 to-rose-500 flex items-center justify-center"
                          >
                            <Zap className="w-6 h-6 text-white" />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Process Section */}
      <section className="py-20 md:py-32 relative">
        <div className="container mx-auto px-4 md:px-8">
          <div className="max-w-7xl mx-auto">
            {/* Section Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-black mb-6">
                Our <span className="text-red-600">Process</span>
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                From concept to launch—a seamless journey of innovation and excellence.
              </p>
            </motion.div>

            {/* Rapid Prototyping Box */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="mb-16"
            >
              <div className="bg-gradient-to-r from-red-600 to-rose-600 text-white rounded-3xl p-8 md:p-10 shadow-2xl">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                    <Rocket className="w-6 h-6" />
                  </div>
                  <h3 className="text-2xl md:text-3xl font-bold italic">Rapid Prototyping</h3>
                </div>
                <p className="text-lg opacity-90 leading-relaxed">
                  We deliver a functional MVP prototype in just 14 days so you can test your ideas with real users immediately.
                </p>
              </div>
            </motion.div>

            {/* Stats Grid */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="mb-20"
            >
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {stats.slice(0, 2).map((stat, index) => (
                  <div key={index} className="text-center p-6 rounded-2xl bg-white dark:bg-gray-900 shadow-lg">
                    <div className="text-red-500 mb-3 flex justify-center">
                      {stat.icon}
                    </div>
                    <div className="text-3xl md:text-4xl font-black bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent mb-2">
                      {stat.value}
                    </div>
                    <div className="text-gray-600 dark:text-gray-400 font-medium text-sm md:text-base">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Divider */}
            <div className="h-px bg-gradient-to-r from-transparent via-red-500/30 to-transparent my-20" />

            {/* Features List */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="mb-20"
            >
              <h3 className="text-3xl md:text-4xl font-black mb-10 text-center">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-rose-500">
                  Our Expertise
                </span>
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {features.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex gap-6 p-6 rounded-2xl bg-white dark:bg-gray-900 shadow-lg hover:shadow-xl transition-shadow"
                  >
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-r from-red-500 to-rose-500 flex items-center justify-center text-white font-bold text-xl">
                        {feature.number}
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <div className="text-red-500">
                          {feature.icon}
                        </div>
                        <h4 className="text-xl font-bold">{feature.title}</h4>
                      </div>
                      <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Process Steps */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="mb-20"
            >
              <h3 className="text-3xl md:text-4xl font-black mb-10 text-center">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-rose-500">
                  Development Process
                </span>
              </h3>
              
              <div className="space-y-8">
                {processSteps.map((step, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex gap-6 p-6 rounded-2xl bg-white dark:bg-gray-900 shadow-lg hover:shadow-xl transition-shadow"
                  >
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-r from-red-500 to-rose-500 flex items-center justify-center text-white font-bold text-xl">
                        {step.number}
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <div className="text-red-500">
                          {step.icon}
                        </div>
                        <h4 className="text-xl font-bold">{step.title}</h4>
                      </div>
                      <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                        {step.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Full Stats Grid */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="mt-20"
            >
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center p-6 rounded-2xl bg-white dark:bg-gray-900 shadow-lg">
                    <div className="text-red-500 mb-3 flex justify-center">
                      {stat.icon}
                    </div>
                    <div className="text-3xl md:text-4xl font-black bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent mb-2">
                      {stat.value}
                    </div>
                    <div className="text-gray-600 dark:text-gray-400 font-medium text-sm md:text-base">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section - Fixed Black Box */}
      <section className="py-20 md:py-32 relative">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="relative overflow-hidden rounded-3xl bg-gray-900 p-8 md:p-12 lg:p-16 shadow-2xl"
          >
            {/* Solid Black Background */}
            <div className="absolute inset-0 bg-gray-900" />
            
            {/* Subtle Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 via-transparent to-rose-900/20" />
            
            {/* Border Effect */}
            <div className="absolute inset-0 rounded-3xl border border-gray-800" />

            <div className="relative z-10 text-center space-y-8">
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-4xl md:text-6xl lg:text-7xl font-black text-white"
              >
                Ready to{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-rose-400">
                  Ignite
                </span>{" "}
                Your Vision?
              </motion.h2>
              
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-xl text-gray-300 max-w-2xl mx-auto"
              >
                Join hundreds of successful businesses with our cutting-edge mobile solutions.
              </motion.p>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="flex flex-col sm:flex-row justify-center gap-4 md:gap-6 pt-4"
              >
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 md:px-10 md:py-5 bg-gradient-to-r from-red-600 to-rose-600 text-white rounded-xl font-bold text-lg md:text-xl shadow-lg relative overflow-hidden group"
                >
                  <span className="relative z-10">Start Your Project</span>
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 md:px-10 md:py-5 bg-white/10 backdrop-blur-sm text-white border-2 border-white/30 rounded-xl font-bold text-lg md:text-xl hover:bg-white/20 transition-colors"
                >
                  Book a Demo
                </motion.button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

  

      {/* Scroll Progress */}
      <motion.div
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-red-500 to-rose-500 z-50"
        style={{ width: progressWidth }}
      />
    </motion.div>
  );
};

export default AppDevPage;