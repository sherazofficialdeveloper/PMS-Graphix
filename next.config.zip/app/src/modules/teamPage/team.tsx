"use client"
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Users, 
  Globe, 
  Award, 
  Calendar,
  Code,
  Palette,
  TrendingUp,
  Server,
  Filter,
  Linkedin,
  Twitter,
  Mail,
  Sparkles,
  Rocket,
  Star,
  Target,
  Zap,
  Shield,
  Brain,
  Heart
} from 'lucide-react';

const TeamPage: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  const departments = ['All', 'Leadership', 'Development', 'Design', 'Marketing'];
  
  const teamMembers = [
    {
      id: 1,
      name: "Alex Morgan",
      role: "CEO & Founder",
      department: "Leadership",
      expertise: "Software Architecture",
      description: "15+ years experience in enterprise software solutions. Passionate about innovation and business growth.",
      imageColor: "from-red-500 to-orange-500",
      icon: <Rocket className="w-6 h-6" />,
      tags: ["Innovation", "Strategy", "Leadership"]
    },
    {
      id: 2,
      name: "Sarah Chen",
      role: "Lead Designer",
      department: "Design",
      expertise: "UI/UX Design",
      description: "Award-winning designer with focus on user-centric experiences and design systems.",
      imageColor: "from-rose-500 to-pink-500",
      icon: <Palette className="w-6 h-6" />,
      tags: ["UX Research", "Design Systems", "Prototyping"]
    },
    {
      id: 3,
      name: "Michael Rodriguez",
      role: "CTO",
      department: "Leadership",
      expertise: "Full Stack Development",
      description: "Expert in scalable systems and modern web technologies. Leads our technical vision.",
      imageColor: "from-red-600 to-rose-600",
      icon: <Code className="w-6 h-6" />,
      tags: ["Architecture", "DevOps", "AI/ML"]
    },
    {
      id: 4,
      name: "Emma Wilson",
      role: "Marketing Director",
      department: "Marketing",
      expertise: "Digital Strategy",
      description: "Driven 300% growth for multiple tech startups. Expert in growth marketing.",
      imageColor: "from-orange-500 to-yellow-500",
      icon: <TrendingUp className="w-6 h-6" />,
      tags: ["Growth", "Analytics", "Branding"]
    },
    {
      id: 5,
      name: "David Kim",
      role: "Senior Developer",
      department: "Development",
      expertise: "React & Node.js",
      description: "Specialized in building high-performance web applications and APIs.",
      imageColor: "from-blue-500 to-cyan-500",
      icon: <Zap className="w-6 h-6" />,
      tags: ["React", "Node.js", "Performance"]
    },
    {
      id: 6,
      name: "Lisa Wang",
      role: "UI/UX Designer",
      department: "Design",
      expertise: "Product Design",
      description: "Creates intuitive interfaces that blend aesthetics with functionality.",
      imageColor: "from-purple-500 to-pink-500",
      icon: <Target className="w-6 h-6" />,
      tags: ["UI Design", "Prototyping", "User Testing"]
    },
    {
      id: 7,
      name: "James Patel",
      role: "DevOps Engineer",
      department: "Development",
      expertise: "Cloud Infrastructure",
      description: "Ensures seamless deployment and 99.9% uptime for all our solutions.",
      imageColor: "from-green-500 to-emerald-500",
      icon: <Server className="w-6 h-6" />,
      tags: ["AWS", "Kubernetes", "CI/CD"]
    },
    {
      id: 8,
      name: "Maria Garcia",
      role: "SEO Specialist",
      department: "Marketing",
      expertise: "Search Optimization",
      description: "Drives organic growth through data-driven SEO strategies.",
      imageColor: "from-yellow-500 to-orange-500",
      icon: <Brain className="w-6 h-6" />,
      tags: ["SEO", "Analytics", "Content"]
    }
  ];
  
  const stats = [
    { value: "20+", label: "Team Members", icon: <Users className="w-8 h-8" />, color: "from-red-500 to-rose-500" },
    { value: "10+", label: "Countries Served", icon: <Globe className="w-8 h-8" />, color: "from-orange-500 to-amber-500" },
    { value: "5+", label: "Years Experience Avg", icon: <Calendar className="w-8 h-8" />, color: "from-amber-500 to-yellow-500" },
    { value: "50+", label: "Certifications", icon: <Award className="w-8 h-8" />, color: "from-yellow-500 to-lime-500" }
  ];

  const filteredMembers = teamMembers.filter(member => {
    const matchesFilter = activeFilter === 'All' || member.department === activeFilter;
    const matchesSearch = searchQuery === '' || 
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.expertise.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white dark:from-gray-950 dark:to-gray-900">
      {/* Hero Section */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 via-transparent to-rose-500/5" />
        <div className="container mx-auto px-4 md:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-red-500/10 to-rose-500/10 text-red-600 dark:text-red-400 mb-6">
              <Sparkles className="w-4 h-4" />
              <span className="text-sm font-bold uppercase tracking-widest">Dream Team</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black mb-6 leading-tight">
              Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-500 to-orange-500">Team</span>
            </h1>
            
            <h2 className="text-2xl md:text-3xl text-gray-600 dark:text-gray-300 mb-8 font-medium">
              Meet the Experts
            </h2>
            
            <p className="text-lg text-gray-500 dark:text-gray-400 max-w-2xl mx-auto leading-relaxed">
              A passionate team of innovators, designers, and developers committed to transforming your digital presence.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 md:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-6 rounded-2xl bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${stat.color} flex items-center justify-center mx-auto mb-4`}>
                  <div className="text-white">
                    {stat.icon}
                  </div>
                </div>
                <div className="text-3xl md:text-4xl font-black bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent mb-2">
                  {stat.value}
                </div>
                <div className="text-gray-600 dark:text-gray-400 font-medium">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Search & Filter Section */}
      <section className="py-12">
        <div className="container mx-auto px-4 md:px-8">
          <div className="max-w-6xl mx-auto">
            {/* Search Bar */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="relative mb-8"
            >
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search team members..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 rounded-xl bg-white dark:bg-gray-900 border-2 border-gray-200 dark:border-gray-800 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 outline-none transition-all"
                />
              </div>
            </motion.div>

            {/* Filter Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mb-12"
            >
              <div className="flex items-center gap-3 mb-4">
                <Filter className="w-5 h-5 text-gray-500" />
                <span className="text-gray-600 dark:text-gray-400 font-medium">Filter by Department:</span>
              </div>
              <div className="flex flex-wrap gap-3">
                {departments.map((dept) => (
                  <button
                    key={dept}
                    onClick={() => setActiveFilter(dept)}
                    className={`px-6 py-3 rounded-xl font-medium transition-all ${
                      activeFilter === dept
                        ? 'bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-lg shadow-red-500/30'
                        : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                    }`}
                  >
                    {dept}
                  </button>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Team Grid */}
      <section className="py-12 pb-32">
        <div className="container mx-auto px-4 md:px-8">
          <div className="max-w-9xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredMembers.map((member, index) => (
                <motion.div
                  key={member.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ 
                    y: -8,
                    transition: { type: "spring", stiffness: 300 }
                  }}
                  className="group"
                >
                  <div className="relative h-full bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300">
                    {/* Department Badge */}
                    <div className="absolute top-4 right-4 z-10">
                      <div className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest ${
                        member.department === 'Leadership' 
                          ? 'bg-gradient-to-r from-red-500/20 to-red-600/20 text-red-600 dark:text-red-400 border border-red-500/30'
                          : member.department === 'Development'
                          ? 'bg-gradient-to-r from-blue-500/20 to-blue-600/20 text-blue-600 dark:text-blue-400 border border-blue-500/30'
                          : member.department === 'Design'
                          ? 'bg-gradient-to-r from-purple-500/20 to-purple-600/20 text-purple-600 dark:text-purple-400 border border-purple-500/30'
                          : 'bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 text-yellow-600 dark:text-yellow-400 border border-yellow-500/30'
                      }`}>
                        {member.department}
                      </div>
                    </div>

                    {/* Avatar */}
                    <div className="relative pt-8 pb-6 px-6">
                      <div className="relative w-24 h-24 mx-auto mb-4">
                        <div className={`absolute inset-0 rounded-full bg-gradient-to-r ${member.imageColor} blur-md opacity-50`} />
                        <div className={`relative w-24 h-24 rounded-full bg-gradient-to-r ${member.imageColor} flex items-center justify-center text-white text-2xl font-bold border-4 border-white dark:border-gray-900 shadow-lg`}>
                          {getInitials(member.name)}
                        </div>
                        
                        {/* Glow Effect */}
                        <div className="absolute -inset-2 rounded-full bg-gradient-to-r from-red-500/20 to-rose-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      </div>

                      {/* Name & Role */}
                      <div className="text-center mb-4">
                        <h3 className="text-xl font-black text-gray-900 dark:text-white mb-1">
                          {member.name}
                        </h3>
                        <div className="text-red-500 font-medium mb-2">
                          {member.role}
                        </div>
                        <div className="flex items-center justify-center gap-2 text-gray-500 dark:text-gray-400 text-sm">
                          {member.icon}
                          <span>{member.expertise}</span>
                        </div>
                      </div>

                      {/* Tags */}
                      <div className="flex flex-wrap justify-center gap-2 mb-6">
                        {member.tags.map((tag, tagIndex) => (
                          <span
                            key={tagIndex}
                            className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs rounded-full"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>

                      {/* Description */}
                      <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed text-center">
                        {member.description}
                      </p>
                    </div>

                    {/* Social Links */}
                    <div className="border-t border-gray-100 dark:border-gray-800 px-6 py-4 bg-gray-50 dark:bg-gray-800/50">
                      <div className="flex justify-center gap-4">
                        <motion.a
                          whileHover={{ scale: 1.1, color: "#0077b5" }}
                          href="#"
                          className="text-gray-400 hover:text-[#0077b5] transition-colors"
                        >
                          <Linkedin className="w-5 h-5" />
                        </motion.a>
                        <motion.a
                          whileHover={{ scale: 1.1, color: "#1da1f2" }}
                          href="#"
                          className="text-gray-400 hover:text-[#1da1f2] transition-colors"
                        >
                          <Twitter className="w-5 h-5" />
                        </motion.a>
                        <motion.a
                          whileHover={{ scale: 1.1, color: "#ef4444" }}
                          href="#"
                          className="text-gray-400 hover:text-red-500 transition-colors"
                        >
                          <Mail className="w-5 h-5" />
                        </motion.a>
                      </div>
                    </div>

                    {/* Hover Gradient */}
                    <div className="absolute inset-0 bg-gradient-to-br from-red-500/0 via-transparent to-rose-500/0 group-hover:from-red-500/5 group-hover:to-rose-500/5 transition-all duration-300 pointer-events-none" />
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Empty State */}
            {filteredMembers.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-20"
              >
                <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-r from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 flex items-center justify-center">
                  <Users className="w-12 h-12 text-gray-400" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                  No team members found
                </h3>
                <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
                  Try adjusting your search or filter to find what you're looking for.
                </p>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-gray-900 via-gray-800 to-black p-12 md:p-16 shadow-2xl"
          >
            <div className="relative z-10 text-center space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="flex items-center justify-center gap-4 mb-4"
              >
                <Heart className="w-8 h-8 text-red-400" />
                <span className="text-red-400 font-bold text-lg">Join Our Family</span>
              </motion.div>
              
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-4xl md:text-6xl lg:text-7xl font-black text-white"
              >
                Ready to <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-rose-400">Join Us</span>?
              </motion.h2>
              
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="text-xl text-gray-300 max-w-2xl mx-auto"
              >
                We're always looking for passionate individuals to join our growing team.
              </motion.p>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
                className="flex flex-col sm:flex-row justify-center gap-4 md:gap-6 pt-4"
              >
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-gradient-to-r from-red-600 to-rose-600 text-white rounded-xl font-bold text-lg shadow-lg relative overflow-hidden group"
                >
                  <span className="relative z-10">View Open Positions</span>
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-white/10 backdrop-blur-sm text-white border-2 border-white/30 rounded-xl font-bold text-lg hover:bg-white/20 transition-colors"
                >
                  Contact Recruiting
                </motion.button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default TeamPage;