"use client"
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Palette, MousePointer2, Layers, Sparkles, ArrowRight, 
  Target, Users, BarChart3, Code2, Smartphone, Monitor,
  ChevronRight, Zap, Shield, Rocket, Globe, Award,
  Sun, Moon, Eye, PenTool, CheckCircle2, Heart,
  Grid3x3, Layout, Fingerprint, Search
} from 'lucide-react';

const UIUXPage: React.FC = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setDarkMode(isDark);
  }, []);

  const handleMouseMove = (e: React.MouseEvent) => {
    setMousePosition({ x: e.clientX, y: e.clientY });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    }
  };

  const cardVariants = {
    hidden: { scale: 0.9, opacity: 0 },
    visible: {
      scale: 1,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 260,
        damping: 20
      }
    },
    hover: {
      y: -10,
      scale: 1.02,
      transition: {
        type: "spring",
        stiffness: 400,
        damping: 25
      }
    }
  };

  const services = [
    {
      icon: <Palette />,
      title: 'UI Design',
      description: 'Pixel-perfect interfaces with stunning visuals',
      color: 'red',
      features: ['Visual Design', 'Typography', 'Color Systems']
    },
    {
      icon: <MousePointer2 />,
      title: 'UX Research',
      description: 'Data-driven insights for better experiences',
      color: 'orange',
      features: ['User Testing', 'Analytics', 'Personas']
    },
    {
      icon: <Layers />,
      title: 'Prototyping',
      description: 'Interactive prototypes for validation',
      color: 'amber',
      features: ['Figma', 'Framer', 'Interactive']
    },
    {
      icon: <Code2 />,
      title: 'Development',
      description: 'Clean, efficient code implementation',
      color: 'emerald',
      features: ['React', 'Next.js', 'TypeScript']
    }
  ];

  const features = [
    {
      icon: <Target />,
      title: 'Goal-Oriented',
      description: 'Every design serves a strategic purpose'
    },
    {
      icon: <Zap />,
      title: 'Fast Iteration',
      description: 'Rapid prototyping and quick feedback loops'
    },
    {
      icon: <Shield />,
      title: 'Quality Assurance',
      description: 'Rigorous testing and quality checks'
    },
    {
      icon: <Rocket />,
      title: 'Performance',
      description: 'Optimized for speed and efficiency'
    }
  ];

  const stats = [
    { value: '99%', label: 'Client Satisfaction' },
    { value: '50+', label: 'Projects Completed' },
    { value: '15+', label: 'Industry Awards' },
    { value: '24/7', label: 'Support Available' }
  ];

  return (
    <div 
      className={`min-h-screen transition-colors duration-500 ${darkMode 
        ? 'bg-gradient-to-br from-gray-900 via-black to-gray-900 text-gray-100' 
        : 'bg-gradient-to-br from-gray-50 via-white to-gray-100 text-gray-900'
      }`}
      onMouseMove={handleMouseMove}
    >
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{
            x: [0, 100, 0],
            y: [0, 50, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className={`absolute w-96 h-96 rounded-full blur-3xl ${darkMode 
            ? 'bg-red-500/10' 
            : 'bg-red-500/5'
          }`}
          style={{ top: '10%', left: '10%' }}
        />
        <motion.div
          animate={{
            x: [0, -100, 0],
            y: [0, -50, 0],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "linear"
          }}
          className={`absolute w-96 h-96 rounded-full blur-3xl ${darkMode 
            ? 'bg-red-500/5' 
            : 'bg-red-500/10'
          }`}
          style={{ bottom: '10%', right: '10%' }}
        />
      </div>

      {/* Theme Toggle */}
      <motion.button
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setDarkMode(!darkMode)}
        className={`fixed top-6 right-6 z-50 p-3 rounded-2xl shadow-2xl backdrop-blur-sm border ${
          darkMode 
            ? 'bg-black/50 border-gray-800 hover:bg-black/70' 
            : 'bg-white/50 border-gray-200 hover:bg-white/70'
        } transition-all`}
      >
        {darkMode ? <Sun className="text-yellow-400" /> : <Moon className="text-gray-700" />}
      </motion.button>

      <div className="relative z-10">
        {/* Hero Section */}
        <section className="container mx-auto px-4 md:px-6 lg:px-8 pt-32 pb-20">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="text-center max-w-6xl mx-auto"
          >
            {/* Badge */}
            <motion.div
              variants={itemVariants}
              className={`inline-flex items-center px-4 py-2 rounded-full mb-8 ${
                darkMode 
                  ? 'bg-red-500/10 border border-red-500/20 text-red-400' 
                  : 'bg-red-500/10 border border-red-500/20 text-red-600'
              }`}
            >
              <Sparkles size={16} className="mr-2" />
              <span className="font-bold text-sm tracking-wider">AWARD WINNING AGENCY</span>
            </motion.div>

            {/* Main Heading */}
            <motion.h1
              variants={itemVariants}
              className={`text-5xl md:text-7xl lg:text-8xl font-black mb-6 leading-tight ${
                darkMode ? 'text-white' : 'text-gray-900'
              }`}
            >
              Design That
              <br />
              <span className="relative">
                <span className={`bg-clip-text text-transparent bg-gradient-to-r ${
                  darkMode 
                    ? 'from-red-400 via-red-500 to-red-600' 
                    : 'from-red-500 via-red-600 to-red-700'
                }`}>
                  Sparks Emotion
                </span>
                <motion.span
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  className="absolute -top-4 -right-4"
                >
                  <Sparkles className={darkMode ? 'text-red-400' : 'text-red-500'} />
                </motion.span>
              </span>
            </motion.h1>

            {/* Description */}
            <motion.p
              variants={itemVariants}
              className={`text-xl md:text-2xl mb-12 max-w-3xl mx-auto ${
                darkMode ? 'text-gray-300' : 'text-gray-600'
              }`}
            >
              We create digital experiences that don't just look good—they feel right, 
              work perfectly, and drive real results for your business.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4 justify-center mb-20">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="group px-8 py-4 rounded-2xl font-bold text-lg flex items-center justify-center bg-gradient-to-r from-red-500 to-red-600 text-white shadow-2xl shadow-red-500/30 hover:shadow-red-500/50 transition-all"
              >
                Start Free Consultation
                <ArrowRight className="ml-3 group-hover:translate-x-2 transition-transform" />
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`px-8 py-4 rounded-2xl font-bold text-lg border-2 backdrop-blur-sm ${
                  darkMode 
                    ? 'bg-gray-900/50 border-gray-700 text-gray-100 hover:bg-gray-800/50' 
                    : 'bg-white/50 border-gray-200 text-gray-800 hover:bg-white/70'
                } transition-all`}
              >
                View Our Work
              </motion.button>
            </motion.div>

            {/* Stats */}
            <motion.div
              variants={containerVariants}
              className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto"
            >
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  variants={itemVariants}
                  whileHover={{ scale: 1.05 }}
                  className={`text-center p-6 rounded-3xl backdrop-blur-sm border ${
                    darkMode 
                      ? 'bg-gray-900/30 border-gray-800' 
                      : 'bg-white/30 border-gray-200'
                  }`}
                >
                  <div className={`text-4xl font-black mb-2 ${
                    darkMode ? 'text-red-400' : 'text-red-600'
                  }`}>
                    {stat.value}
                  </div>
                  <div className={`text-sm font-medium ${
                    darkMode ? 'text-gray-400' : 'text-gray-600'
                  }`}>
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </section>

        {/* Services Section */}
        <section className="py-20">
          <div className="container mx-auto px-4 md:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className={`text-4xl md:text-5xl font-black mb-6 ${
                darkMode ? 'text-white' : 'text-gray-900'
              }`}>
                Our <span className="text-red-500">Expert</span> Services
              </h2>
              <p className={`text-xl max-w-2xl mx-auto ${
                darkMode ? 'text-gray-300' : 'text-gray-600'
              }`}>
                Comprehensive design and development solutions tailored to your needs
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {services.map((service, index) => (
                <motion.div
                  key={service.title}
                  variants={cardVariants}
                  initial="hidden"
                  whileInView="visible"
                  whileHover="hover"
                  viewport={{ once: true }}
                  onHoverStart={() => setHoveredCard(index)}
                  onHoverEnd={() => setHoveredCard(null)}
                  className={`relative overflow-hidden rounded-3xl p-8 backdrop-blur-sm border ${
                    darkMode 
                      ? 'bg-gray-900/30 border-gray-800 hover:border-red-500/50' 
                      : 'bg-white/30 border-gray-200 hover:border-red-500/50'
                  } transition-all duration-300`}
                >
                  {/* Hover Effect */}
                  <AnimatePresence>
                    {hoveredCard === index && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        className={`absolute inset-0 bg-gradient-to-br ${
                          darkMode 
                            ? 'from-red-500/10 to-red-600/5' 
                            : 'from-red-500/5 to-red-600/2'
                        }`}
                      />
                    )}
                  </AnimatePresence>

                  {/* Icon */}
                  <div className={`relative z-10 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 ${
                    darkMode 
                      ? 'bg-red-500/20' 
                      : 'bg-red-500/10'
                  }`}>
                    <div className={darkMode ? 'text-red-400' : 'text-red-600'}>
                      {service.icon}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="relative z-10">
                    <h3 className={`text-2xl font-bold mb-3 ${
                      darkMode ? 'text-white' : 'text-gray-900'
                    }`}>
                      {service.title}
                    </h3>
                    <p className={`mb-6 ${
                      darkMode ? 'text-gray-300' : 'text-gray-600'
                    }`}>
                      {service.description}
                    </p>
                    
                    <ul className="space-y-2 mb-6">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center">
                          <CheckCircle2 className={`mr-2 ${darkMode ? 'text-red-400' : 'text-red-500'}`} size={16} />
                          <span className={darkMode ? 'text-gray-300' : 'text-gray-600'}>
                            {feature}
                          </span>
                        </li>
                      ))}
                    </ul>
                    
                    <button className={`flex items-center font-semibold ${
                      darkMode ? 'text-red-400' : 'text-red-600'
                    } group`}>
                      Learn More
                      <ChevronRight className="ml-2 group-hover:translate-x-2 transition-transform" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20">
          <div className="container mx-auto px-4 md:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className={`text-4xl md:text-5xl font-black mb-6 ${
                darkMode ? 'text-white' : 'text-gray-900'
              }`}>
                Why Choose <span className="text-red-500">Us</span>
              </h2>
              <p className={`text-xl max-w-2xl mx-auto ${
                darkMode ? 'text-gray-300' : 'text-gray-600'
              }`}>
                We combine cutting-edge technology with creative design thinking
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -10 }}
                  className={`text-center p-8 rounded-3xl backdrop-blur-sm border ${
                    darkMode 
                      ? 'bg-gray-900/30 border-gray-800 hover:border-red-500/50' 
                      : 'bg-white/30 border-gray-200 hover:border-red-500/50'
                  } transition-all duration-300`}
                >
                  <div className={`inline-block p-4 rounded-2xl mb-6 ${
                    darkMode 
                      ? 'bg-red-500/20 text-red-400' 
                      : 'bg-red-500/10 text-red-600'
                  }`}>
                    {feature.icon}
                  </div>
                  <h3 className={`text-2xl font-bold mb-3 ${
                    darkMode ? 'text-white' : 'text-gray-900'
                  }`}>
                    {feature.title}
                  </h3>
                  <p className={darkMode ? 'text-gray-300' : 'text-gray-600'}>
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20">
          <div className="container mx-auto px-4 md:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className={`relative overflow-hidden rounded-[4rem] p-12 md:p-16 ${
                darkMode 
                  ? 'bg-gradient-to-br from-gray-900 via-black to-gray-900' 
                  : 'bg-gradient-to-br from-gray-50 via-white to-gray-100'
              } border ${darkMode ? 'border-gray-800' : 'border-gray-200'}`}
            >
              {/* Decorative Elements */}
              <div className={`absolute -top-20 -right-20 w-40 h-40 rounded-full blur-3xl ${
                darkMode ? 'bg-red-500/10' : 'bg-red-500/5'
              }`} />
              <div className={`absolute -bottom-20 -left-20 w-40 h-40 rounded-full blur-3xl ${
                darkMode ? 'bg-red-500/10' : 'bg-red-500/5'
              }`} />

              <div className="relative z-10 text-center max-w-4xl mx-auto">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="space-y-8"
                >
                  <div className={`inline-block p-4 rounded-2xl ${
                    darkMode 
                      ? 'bg-red-500/20 text-red-400' 
                      : 'bg-red-500/10 text-red-600'
                  }`}>
                    <Rocket size={48} />
                  </div>

                  <h2 className={`text-4xl md:text-5xl lg:text-6xl font-black ${
                    darkMode ? 'text-white' : 'text-gray-900'
                  }`}>
                    Ready to
                    <br />
                    <span className="text-red-500">Transform</span> Your Business?
                  </h2>

                  <p className={`text-xl md:text-2xl ${
                    darkMode ? 'text-gray-300' : 'text-gray-600'
                  }`}>
                    Let's create something amazing together. Get started with a free consultation.
                  </p>

                  <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="px-10 py-5 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-2xl font-bold text-lg shadow-2xl shadow-red-500/30 hover:shadow-red-500/50 transition-all"
                    >
                      Start Your Project
                    </motion.button>
                    
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className={`px-10 py-5 rounded-2xl font-bold text-lg border-2 backdrop-blur-sm ${
                        darkMode 
                          ? 'bg-gray-900/50 border-gray-700 text-gray-100 hover:bg-gray-800/50' 
                          : 'bg-white/50 border-gray-200 text-gray-800 hover:bg-white/70'
                      } transition-all`}
                    >
                      Schedule a Call
                    </motion.button>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </section>

    
      </div>

      {/* Mouse Follow Effect */}
      <motion.div
        className="fixed top-0 left-0 w-4 h-4 rounded-full pointer-events-none z-50 mix-blend-difference"
        animate={{
          x: mousePosition.x - 8,
          y: mousePosition.y - 8,
        }}
        transition={{
          type: "spring",
          stiffness: 500,
          damping: 28
        }}
      >
        <div className={`w-full h-full rounded-full ${
          darkMode ? 'bg-red-400' : 'bg-red-500'
        }`} />
      </motion.div>
    </div>
  );
};

export default UIUXPage;