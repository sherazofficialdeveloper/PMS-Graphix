// components/TeamSection.jsx
"use client";

import { useState, useEffect } from 'react';
import { motion, Variants } from 'framer-motion';
import { FaLinkedin, FaTwitter, FaInstagram, FaGithub, FaArrowRight, FaSun, FaMoon } from 'react-icons/fa';
import { MdEmail } from 'react-icons/md';


const TeamSection = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);

  // Initialize dark mode based on system preference
  useEffect(() => {
    const isSystemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setIsDarkMode(isSystemDark);
  }, []);

  // Toggle dark mode
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  // Team members data
  const teamMembers = [
    {
      id: 1,
      name: "Alex Morgan",
      position: "CEO & Founder",
      expertise: "Software Architecture",
      description: "15+ years experience in enterprise software solutions. Specializes in building robust, scalable architectures for Fortune 500 companies.",
      image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      social: { linkedin: "#", twitter: "#", email: "#" }
    },
    {
      id: 2,
      name: "Sarah Chen",
      position: "Lead Designer",
      expertise: "UI/UX Design",
      description: "Award-winning designer with focus on user-centric experiences. Passionate about creating intuitive and beautiful interfaces.",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      social: { linkedin: "#", twitter: "#", instagram: "#" }
    },
    {
      id: 3,
      name: "Michael Rodriguez",
      position: "CTO",
      expertise: "Full Stack Development",
      description: "Expert in scalable systems and modern web technologies. Leads development of cutting-edge solutions with focus on performance.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      social: { linkedin: "#", twitter: "#", github: "#" }
    },
    {
      id: 4,
      name: "Emma Wilson",
      position: "Marketing Director",
      expertise: "Digital Strategy",
      description: "Driven 300% growth for multiple tech startups. Expert in digital marketing, SEO, and brand strategy development.",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      social: { linkedin: "#", twitter: "#", email: "#" }
    }
  ];

  // Additional team members to show when "Meet Full Team" is clicked
  const additionalMembers = [
    {
      id: 5,
      name: "James Lee",
      position: "Senior Developer",
      expertise: "Backend Systems",
      description: "Expert in microservices architecture and cloud infrastructure. Built scalable APIs serving millions of users.",
      image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      social: { linkedin: "#", github: "#" }
    },
    {
      id: 6,
      name: "Priya Sharma",
      position: "Product Manager",
      expertise: "Product Strategy",
      description: "Drives product vision and roadmap. Successfully launched 10+ products with market fit and high user adoption.",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      social: { linkedin: "#", twitter: "#" }
    },
    {
      id: 7,
      name: "David Kim",
      position: "DevOps Engineer",
      expertise: "Cloud Infrastructure",
      description: "Specializes in CI/CD pipelines and cloud optimization. Reduced deployment time by 80% across multiple projects.",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      social: { linkedin: "#", twitter: "#", github: "#" }
    },
    {
      id: 8,
      name: "Olivia Martinez",
      position: "Content Strategist",
      expertise: "Brand Communication",
      description: "Creates compelling brand narratives and content strategies. Increased engagement by 200% across digital platforms.",
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      social: { linkedin: "#", instagram: "#" }
    }
  ];

  const [showFullTeam, setShowFullTeam] = useState(false);
  const [animationKey, setAnimationKey] = useState(0);

  const toggleFullTeam = () => {
    setShowFullTeam(!showFullTeam);
    setAnimationKey(prev => prev + 1);
  };

  // Animation variants
 const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};


  const cardVariants:Variants = {
    hidden: { 
      opacity: 0, 
      y: 50,
      scale: 0.9
    },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    },
    hover: {
      y: -10,
      scale: 1.03,
      boxShadow: isDarkMode 
        ? "0 20px 40px rgba(239, 68, 68, 0.3)" 
        : "0 20px 40px rgba(239, 68, 68, 0.2)",
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    }
  };

  const titleVariants: Variants = {
    hidden: { opacity: 0, y: -30 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    }
  };

  return (
    <section className={`min-h-screen py-16 px-4 md:px-8 transition-colors duration-500 ${isDarkMode ? 'bg-gradient-to-br from-gray-900 to-black text-white' : 'bg-gradient-to-br from-gray-50 to-white text-gray-900'}`}>
      {/* Theme Toggle */}
      <div className="flex justify-end max-w-7xl mx-auto mb-8">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={toggleDarkMode}
          className={`p-3 rounded-full ${isDarkMode ? 'bg-red-500/20 hover:bg-red-500/30' : 'bg-red-100 hover:bg-red-200'} transition-colors duration-300`}
          aria-label="Toggle dark mode"
        >
          {isDarkMode ? <FaSun className="text-red-500 text-xl" /> : <FaMoon className="text-red-500 text-xl" />}
        </motion.button>
      </div>

      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div 
          className="text-center mb-12"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <motion.div 
            className="inline-block mb-4"
            initial={{ scale: 0 }}
            animate={{ rotate: 360, scale: 1 }}
            transition={{
              type: "spring",
              stiffness: 260,
              damping: 20,
              delay: 0.2
            }}
          >
            <div className={`w-16 h-16 rounded-full flex items-center justify-center ${isDarkMode ? 'bg-red-500/20' : 'bg-red-100'}`}>
              <span className="text-2xl font-bold text-red-500">T</span>
            </div>
          </motion.div>
          
          <motion.h2 
            variants={titleVariants}
            className="text-4xl md:text-5xl font-bold mb-4"
          >
            <span className="text-red-500">Our</span> Team
          </motion.h2>
          
          <motion.p 
            variants={titleVariants}
            className={`text-xl max-w-3xl mx-auto mb-8 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}
          >
            Meet our passionate team of innovators, designers, and developers committed to excellence.
          </motion.p>
          
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: "150px" }}
            transition={{ delay: 0.8, duration: 1 }}
            className="h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent mx-auto"
          />
        </motion.div>

        {/* Meet Our Experts Subtitle */}
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <h3 className="text-3xl font-bold mb-4">
            <span className={`px-4 py-2 rounded-lg ${isDarkMode ? 'bg-red-500/10' : 'bg-red-50'}`}>
              Meet Our <span className="text-red-500">Experts</span>
            </span>
          </h3>
          <p className={`text-lg ${isDarkMode ? 'text-gray-300' : 'text-gray-600'} max-w-2xl mx-auto`}>
            A passionate team of innovators, designers, and developers committed to pushing boundaries and delivering exceptional solutions.
          </p>
        </motion.div>

        {/* Team Members Grid */}
        <motion.div 
          key={animationKey}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {teamMembers.map((member, index) => (
            <motion.div
              key={member.id}
              variants={cardVariants}
              initial="hidden"
              animate="visible"
              whileHover="hover"
              onMouseEnter={() => setHoveredCard(member.id)}
              onMouseLeave={() => setHoveredCard(null)}
              className={`rounded-2xl overflow-hidden border-2 ${isDarkMode ? 'border-gray-800 bg-gray-900' : 'border-gray-200 bg-white'}`}
              style={{
                transform: hoveredCard === member.id ? 'perspective(1000px) rotateY(5deg)' : 'perspective(1000px) rotateY(0deg)',
                transformStyle: 'preserve-3d',
                transition: 'transform 0.5s ease'
              }}
            >
              {/* Card Image with Animation */}
              <div className="relative h-64 overflow-hidden">
                <motion.div
                  className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent z-10"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: hoveredCard === member.id ? 1 : 0.5 }}
                  transition={{ duration: 0.3 }}
                />
                <motion.img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover"
                  initial={{ scale: 1 }}
                  animate={{ scale: hoveredCard === member.id ? 1.1 : 1 }}
                  transition={{ duration: 0.5 }}
                />
                
                {/* Expertise Badge */}
                <motion.div 
                  className="absolute top-4 right-4 z-20"
                  initial={{ x: 50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                >
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${isDarkMode ? 'bg-red-500 text-white' : 'bg-red-100 text-red-700'}`}>
                    {member.expertise}
                  </span>
                </motion.div>
              </div>

              {/* Card Content */}
              <div className="p-6">
                <motion.h3 
                  className="text-2xl font-bold mb-1"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                >
                  {member.name}
                </motion.h3>
                <motion.p 
                  className={`text-lg font-semibold mb-3 ${isDarkMode ? 'text-red-400' : 'text-red-600'}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                >
                  {member.position}
                </motion.p>
                <motion.p 
                  className={`mb-6 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                >
                  {member.description}
                </motion.p>

                {/* Social Links */}
                <motion.div 
                  className="flex space-x-3"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                >
                  {member.social.linkedin && (
                    <motion.a
                      href={member.social.linkedin}
                      whileHover={{ y: -3, scale: 1.2 }}
                      className={`p-2 rounded-full ${isDarkMode ? 'bg-gray-800 hover:bg-red-500/20' : 'bg-gray-100 hover:bg-red-100'}`}
                    >
                      <FaLinkedin className="text-red-500" />
                    </motion.a>
                  )}
                  {member.social.twitter && (
                    <motion.a
                      href={member.social.twitter}
                      whileHover={{ y: -3, scale: 1.2 }}
                      className={`p-2 rounded-full ${isDarkMode ? 'bg-gray-800 hover:bg-red-500/20' : 'bg-gray-100 hover:bg-red-100'}`}
                    >
                      <FaTwitter className="text-red-500" />
                    </motion.a>
                  )}
                  {member.social.instagram && (
                    <motion.a
                      href={member.social.instagram}
                      whileHover={{ y: -3, scale: 1.2 }}
                      className={`p-2 rounded-full ${isDarkMode ? 'bg-gray-800 hover:bg-red-500/20' : 'bg-gray-100 hover:bg-red-100'}`}
                    >
                      <FaInstagram className="text-red-500" />
                    </motion.a>
                  )}
                  {member.social.github && (
                    <motion.a
                      href={member.social.github}
                      whileHover={{ y: -3, scale: 1.2 }}
                      className={`p-2 rounded-full ${isDarkMode ? 'bg-gray-800 hover:bg-red-500/20' : 'bg-gray-100 hover:bg-red-100'}`}
                    >
                      <FaGithub className="text-red-500" />
                    </motion.a>
                  )}
                  {member.social.email && (
                    <motion.a
                      href={member.social.email}
                      whileHover={{ y: -3, scale: 1.2 }}
                      className={`p-2 rounded-full ${isDarkMode ? 'bg-gray-800 hover:bg-red-500/20' : 'bg-gray-100 hover:bg-red-100'}`}
                    >
                      <MdEmail className="text-red-500" />
                    </motion.a>
                  )}
                </motion.div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Additional Team Members (Shown when toggled) */}
        {showFullTeam && (
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.5 }}
          >
            {additionalMembers.map((member, index) => (
              <motion.div
                key={member.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className={`rounded-2xl overflow-hidden border-2 ${isDarkMode ? 'border-gray-800 bg-gray-900' : 'border-gray-200 bg-white'}`}
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${isDarkMode ? 'bg-red-500 text-white' : 'bg-red-100 text-red-700'}`}>
                      {member.expertise}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                  <p className={`text-lg font-semibold mb-3 ${isDarkMode ? 'text-red-400' : 'text-red-600'}`}>
                    {member.position}
                  </p>
                  <p className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-600'} mb-4`}>
                    {member.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Meet Full Team Button */}
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
        >
          <motion.button
            onClick={toggleFullTeam}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`group relative px-8 py-4 rounded-full font-bold text-lg overflow-hidden ${isDarkMode ? 'bg-red-600 hover:bg-red-700' : 'bg-red-500 hover:bg-red-600'} text-white transition-all duration-300`}
          >
            <motion.span 
              className="flex items-center justify-center"
              initial={{ x: 0 }}
              whileHover={{ x: 5 }}
            >
              {showFullTeam ? "Show Less" : "Meet Full Team"}
              <FaArrowRight className={`ml-3 transition-transform duration-300 ${showFullTeam ? 'rotate-180' : 'group-hover:translate-x-2'}`} />
            </motion.span>
            
            {/* Button shine effect */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
              initial={{ x: "-100%" }}
              whileHover={{ x: "100%" }}
              transition={{ duration: 0.6 }}
            />
          </motion.button>
          
          {/* Stats Section */}
          <motion.div 
            className={`mt-16 p-8 rounded-2xl ${isDarkMode ? 'bg-gray-900/50' : 'bg-gray-100'}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
          >
            <h3 className="text-2xl font-bold mb-8 text-center">Our Collective Impact</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[
                { label: "Projects Delivered", value: "500+" },
                { label: "Years Combined Experience", value: "85+" },
                { label: "Client Satisfaction", value: "99%" },
                { label: "Awards Won", value: "42" }
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  className="text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.3 + index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                >
                  <div className={`text-4xl md:text-5xl font-bold mb-2 ${isDarkMode ? 'text-red-400' : 'text-red-600'}`}>
                    {stat.value}
                  </div>
                  <div className={`font-medium ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          {/* Final CTA */}
          <motion.div 
            className="mt-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
          >
            <p className={`text-lg mb-6 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              Interested in joining our talented team? We're always looking for passionate individuals.
            </p>
            <motion.a
              href="#"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center px-6 py-3 rounded-lg font-semibold border-2 border-red-500 text-red-500 hover:bg-red-500 hover:text-white transition-all duration-300"
            >
              View Career Opportunities
              <FaArrowRight className="ml-2 group-hover:translate-x-2 transition-transform" />
            </motion.a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default TeamSection;