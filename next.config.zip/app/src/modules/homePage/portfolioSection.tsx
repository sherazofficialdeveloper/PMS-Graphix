'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import {
  ExternalLink,
  Github,
  Smartphone,
  Globe,
  Cpu,
  Code,
  ShoppingCart,
  Banknote,
  LineChart,
  Dumbbell,
  Users,
  Utensils,
  Filter,
  ChevronRight,
  Sparkles,
  Eye,
  Zap,
  Shield,
  Clock,
  TrendingUp,
  Palette,
  Database
} from 'lucide-react';

// Portfolio projects data
const projects = [
  {
    id: 1,
    title: 'E-Commerce Platform',
    category: 'Web Development',
    description: 'A full-featured e-commerce solution with real-time inventory management and AI-powered recommendations.',
    tags: ['React', 'Node.js', 'MongoDB', 'AWS', 'Redux', 'Stripe'],
    icon: <ShoppingCart className="w-8 h-8" />,
    color: 'from-red-500 to-orange-500',
    bgColor: 'bg-gradient-to-br from-red-500/10 to-orange-500/10',
    features: ['Real-time Inventory', 'AI Recommendations', 'Secure Payments'],
    liveLink: '#',
    githubLink: '#'
  },
  {
    id: 2,
    title: 'Mobile Banking App',
    category: 'Mobile App',
    description: 'Secure banking application with biometric authentication, instant transfers, and financial analytics.',
    tags: ['React Native', 'Firebase', 'Node.js', 'Redux', 'Biometric'],
    icon: <Banknote className="w-8 h-8" />,
    color: 'from-red-600 to-pink-500',
    bgColor: 'bg-gradient-to-br from-red-600/10 to-pink-500/10',
    features: ['Biometric Auth', 'Instant Transfers', 'Financial Analytics'],
    liveLink: '#',
    githubLink: '#'
  },
  {
    id: 3,
    title: 'AI-Powered Analytics Dashboard',
    category: 'AI/ML',
    description: 'Real-time business intelligence dashboard with predictive analytics and automated insights.',
    tags: ['Python', 'TensorFlow', 'React', 'D3.js', 'FastAPI'],
    icon: <LineChart className="w-8 h-8" />,
    color: 'from-red-500 to-rose-500',
    bgColor: 'bg-gradient-to-br from-red-500/10 to-rose-500/10',
    features: ['Predictive Analytics', 'Real-time Data', 'Automated Insights'],
    liveLink: '#',
    githubLink: '#'
  },
  {
    id: 4,
    title: 'Fitness Tracking App',
    category: 'Mobile App',
    description: 'Comprehensive fitness tracking with AI workout recommendations and health monitoring.',
    tags: ['Flutter', 'Firebase', 'HealthKit', 'Google Fit', 'AI'],
    icon: <Dumbbell className="w-8 h-8" />,
    color: 'from-orange-500 to-red-500',
    bgColor: 'bg-gradient-to-br from-orange-500/10 to-red-500/10',
    features: ['AI Workouts', 'Health Sync', 'Progress Tracking'],
    liveLink: '#',
    githubLink: '#'
  },
  {
    id: 5,
    title: 'Enterprise CRM System',
    category: 'Software Development',
    description: 'Custom CRM solution for enterprise sales, customer management, and automation workflows.',
    tags: ['.NET', 'SQL Server', 'Angular', 'Azure', 'Microservices'],
    icon: <Users className="w-8 h-8" />,
    color: 'from-red-700 to-red-500',
    bgColor: 'bg-gradient-to-br from-red-700/10 to-red-500/10',
    features: ['Sales Automation', 'Customer Management', 'Workflow Builder'],
    liveLink: '#',
    githubLink: '#'
  },
  {
    id: 6,
    title: 'Food Delivery Platform',
    category: 'Web Development',
    description: 'Multi-vendor food delivery platform with real-time tracking and intelligent route optimization.',
    tags: ['Next.js', 'Express.js', 'PostgreSQL', 'Socket.io', 'Mapbox'],
    icon: <Utensils className="w-8 h-8" />,
    color: 'from-red-500 to-amber-500',
    bgColor: 'bg-gradient-to-br from-red-500/10 to-amber-500/10',
    features: ['Real-time Tracking', 'Multi-vendor', 'Route Optimization'],
    liveLink: '#',
    githubLink: '#'
  }
];

const categories = [
  { id: 'all', label: 'All', icon: <Filter className="w-4 h-4" /> },
  { id: 'web', label: 'Web Development', icon: <Globe className="w-4 h-4" /> },
  { id: 'mobile', label: 'Mobile App', icon: <Smartphone className="w-4 h-4" /> },
  { id: 'ai', label: 'AI/ML', icon: <Cpu className="w-4 h-4" /> },
  { id: 'software', label: 'Software Development', icon: <Code className="w-4 h-4" /> }
];

const stats = [
  { value: '50+', label: 'Projects Completed', icon: <Zap className="w-5 h-5" /> },
  { value: '100%', label: 'Client Satisfaction', icon: <Sparkles className="w-5 h-5" /> },
  { value: '24/7', label: 'Support Available', icon: <Shield className="w-5 h-5" /> },
  { value: '2x', label: 'Faster Delivery', icon: <Clock className="w-5 h-5" /> }
];

export default function PortfolioSection() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [hoveredProject, setHoveredProject] = useState<number | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Check system preference for dark mode
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    setIsDarkMode(mediaQuery.matches);
    
    const handler = (e: MediaQueryListEvent) => setIsDarkMode(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  // Filter projects based on active category
  const filteredProjects = projects.filter(project => {
    if (activeCategory === 'all') return true;
    const categoryMap: Record<string, string> = {
      'web': 'Web Development',
      'mobile': 'Mobile App',
      'ai': 'AI/ML',
      'software': 'Software Development'
    };
    return project.category === categoryMap[activeCategory];
  });

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: "easeOut",
    },
  },
};

  return (
    <section className={`relative py-24 px-4 overflow-hidden ${isDarkMode ? 'bg-gray-900' : 'bg-gradient-to-b from-gray-50 to-white'}`}>
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{
            x: [0, 100, 0],
            y: [0, 50, 0],
            rotate: [0, 180, 360]
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className={`absolute top-20 left-10 w-64 h-64 rounded-full blur-3xl ${isDarkMode ? 'bg-red-900/20' : 'bg-red-200/20'}`}
        />
        <motion.div
          animate={{
            x: [0, -100, 0],
            y: [0, -50, 0],
            rotate: [0, -180, -360]
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "linear"
          }}
          className={`absolute bottom-20 right-10 w-80 h-80 rounded-full blur-3xl ${isDarkMode ? 'bg-red-800/20' : 'bg-red-300/20'}`}
        />
      </div>

      <div className="relative max-w-7xl mx-auto">
        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-red-500/10 to-red-600/10 backdrop-blur-sm border border-red-200 dark:border-red-800 mb-6"
          >
            <Sparkles className="w-5 h-5 text-red-600 dark:text-red-400 animate-pulse" />
            <span className="text-red-700 dark:text-red-300 font-semibold">PORTFOLIO</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className={`text-5xl md:text-7xl font-bold mb-6 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}
          >
            Featured{' '}
            <span className="bg-gradient-to-r from-red-600 via-red-500 to-orange-500 bg-clip-text text-transparent">
              Projects
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className={`text-xl max-w-3xl mx-auto ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}
          >
            Explore our handpicked selection of projects that showcase our expertise and creativity.
          </motion.p>

          {/* Animated underline */}
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: 200 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="h-1 bg-gradient-to-r from-red-500 to-orange-500 rounded-full mx-auto mt-8"
          />
        </motion.div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className={`p-6 rounded-2xl border backdrop-blur-sm ${isDarkMode 
                ? 'bg-gray-800/50 border-gray-700' 
                : 'bg-white/50 border-gray-200'
              } text-center`}
            >
              <div className="flex justify-center mb-3">
                <div className="p-3 rounded-full bg-gradient-to-r from-red-500/20 to-orange-500/20">
                  <div className="text-red-600 dark:text-red-400">{stat.icon}</div>
                </div>
              </div>
              <div className="text-3xl font-bold text-red-600 dark:text-red-400 mb-1">
                {stat.value}
              </div>
              <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {stat.label}
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Filter Buttons */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {categories.map((category) => (
            <motion.button
              key={category.id}
              variants={itemVariants}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveCategory(category.id)}
              className={`group flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all ${activeCategory === category.id
                  ? 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-lg shadow-red-500/30'
                  : isDarkMode
                    ? 'bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700'
                    : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-200'
                }`}
            >
              <span>{category.icon}</span>
              <span>{category.label}</span>
              {activeCategory === category.id && (
                <motion.div
                  layoutId="activeCategory"
                  className="absolute inset-0 rounded-full bg-gradient-to-r from-red-600 to-orange-500 -z-10"
                />
              )}
            </motion.button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeCategory}
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            exit="hidden"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16"
          >
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                variants={itemVariants}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                whileHover={{ y: -10 }}
                onMouseEnter={() => setHoveredProject(project.id)}
                onMouseLeave={() => setHoveredProject(null)}
                className={`group relative rounded-2xl overflow-hidden border backdrop-blur-sm ${isDarkMode
                    ? 'bg-gray-800/30 border-gray-700'
                    : 'bg-white border-gray-200'
                  } shadow-lg hover:shadow-2xl transition-all duration-300`}
              >
                {/* Hover overlay */}
                <motion.div
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-orange-500/5"
                />

                {/* Project badge */}
                <div className="absolute top-4 left-4 z-10">
                  <div className={`px-3 py-1 rounded-full text-sm font-medium ${isDarkMode
                      ? 'bg-red-900/50 text-red-200'
                      : 'bg-red-100 text-red-700'
                    }`}>
                    {project.category}
                  </div>
                </div>

                {/* Project icon */}
                <div className="p-8">
                  <motion.div
                    whileHover={{ rotate: 360, scale: 1.1 }}
                    transition={{ duration: 0.5 }}
                    className={`w-20 h-20 rounded-2xl ${project.bgColor} flex items-center justify-center mb-6`}
                  >
                    <div className={`bg-gradient-to-r ${project.color} bg-clip-text text-transparent`}>
                      {project.icon}
                    </div>
                  </motion.div>

                  {/* Project title */}
                  <h3 className={`text-2xl font-bold mb-3 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {project.title}
                  </h3>

                  {/* Project description */}
                  <p className={`mb-6 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                    {project.description}
                  </p>

                  {/* Features */}
                  <div className="space-y-2 mb-6">
                    {project.features.map((feature, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-red-500" />
                        <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {feature}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-8">
                    {project.tags.map((tag, i) => (
                      <motion.span
                        key={i}
                        initial={{ scale: 0 }}
                        whileInView={{ scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.05 }}
                        className={`px-3 py-1 rounded-full text-xs font-medium ${isDarkMode
                            ? 'bg-gray-700 text-gray-300'
                            : 'bg-gray-100 text-gray-700'
                          }`}
                      >
                        {tag}
                      </motion.span>
                    ))}
                  </div>

                  {/* Action buttons */}
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="flex gap-3"
                  >
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-gradient-to-r from-red-600 to-orange-500 text-white font-medium hover:shadow-lg hover:shadow-red-500/30 transition-shadow"
                    >
                      <ExternalLink className="w-4 h-4" />
                      View Details
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className={`p-3 rounded-lg border ${isDarkMode
                          ? 'border-gray-600 hover:bg-gray-700'
                          : 'border-gray-300 hover:bg-gray-100'
                        } transition-colors`}
                    >
                      <Github className="w-5 h-5" />
                    </motion.button>
                  </motion.div>
                </div>

                {/* Animated border on hover */}
                <motion.div
                  initial={{ width: 0 }}
                  whileHover={{ width: '100%' }}
                  className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 to-orange-500"
                />
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="group inline-flex items-center gap-3 px-10 py-4 rounded-full bg-gradient-to-r from-red-600 to-orange-500 text-white font-bold text-lg shadow-xl hover:shadow-2xl hover:shadow-red-500/40 transition-all"
          >
            <span>View Full Portfolio</span>
            <motion.div
              animate={{ x: [0, 5, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <ChevronRight className="w-5 h-5" />
            </motion.div>
            
            {/* Shimmer effect */}
            <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent group-hover:translate-x-full transition-transform duration-1000" />
          </motion.button>

          {/* Decorative elements */}
          <div className="flex justify-center gap-6 mt-12">
            {[Palette, Database, Code, TrendingUp].map((Icon, index) => (
              <motion.div
                key={index}
                animate={{ y: [0, -10, 0] }}
                transition={{
                  duration: 2,
                  delay: index * 0.2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className={`p-4 rounded-xl ${isDarkMode
                    ? 'bg-gray-800/50 border border-gray-700'
                    : 'bg-white/50 border border-gray-200'
                  }`}
              >
                <Icon className={`w-6 h-6 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}