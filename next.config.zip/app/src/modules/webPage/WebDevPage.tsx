'use client';

import React from 'react';
import { motion, Variants } from 'framer-motion';
import { 
  Code, Cpu, Zap, ShieldCheck, ArrowRight, 
  Database, Server, Monitor, Rocket, CheckCircle2,
  ShoppingBag as ShoppingBagIcon
} from 'lucide-react';

interface FeatureCard {
  icon: React.ReactElement;
  title: string;
  desc: string;
  color: string;
}

interface PhaseCard {
  title: string;
  items: string[];
  index: number;
}

interface FAQItem {
  q: string;
  a: string;
}

const WebDevPage: React.FC = () => {
  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1, 
      transition: { 
        staggerChildren: 0.1,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants: Variants = {
    hidden: { 
      y: 25, 
      opacity: 0,
    },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { 
        duration: 0.5, 
        ease: "easeOut"
      }
    }
  };

  const faqVariantsLeft: Variants = {
    hidden: { 
      x: -50, 
      opacity: 0,
    },
    visible: { 
      x: 0, 
      opacity: 1,
      transition: { 
        duration: 0.5,
        ease: "easeOut"
      }
    }
  };

  const faqVariantsRight: Variants = {
    hidden: { 
      x: 50, 
      opacity: 0,
    },
    visible: { 
      x: 0, 
      opacity: 1,
      transition: { 
        duration: 0.5,
        ease: "easeOut"
      }
    }
  };

  const floatAnimation = {
    y: [0, -5, 0],
    transition: {
      duration: 2.5,
      repeat: Infinity,
      ease: "easeInOut"
    }
  };

  const faqs: FAQItem[] = [
    { 
      q: "What tech stack do you use?", 
      a: "We use modern frameworks including React.js, Next.js, Vue.js, Node.js, Tailwind CSS, MongoDB, and PostgreSQL." 
    },
    { 
      q: "How do you ensure security?", 
      a: "SSL/TLS encryption, CSRF protection, regular security audits, and following best security practices." 
    },
    { 
      q: "Will my website be mobile-friendly?", 
      a: "Yes! We use mobile-first responsive design with thorough testing across all devices." 
    },
    { 
      q: "What is your development timeline?", 
      a: "Typically 4-8 weeks depending on complexity, with regular updates throughout the process." 
    },
    { 
      q: "Do you provide maintenance?", 
      a: "Yes, we offer ongoing maintenance, updates, security patches, and technical support." 
    },
    { 
      q: "What is your pricing model?", 
      a: "We offer fixed pricing for defined projects or flexible hourly rates for ongoing work." 
    }
  ];

  const features: FeatureCard[] = [
    { 
      icon: <Server />, 
      title: 'Scalable Backend', 
      desc: 'Node.js, Express, and microservices architecture for high performance applications.',
      color: 'bg-red-500/10 text-red-500'
    },
    { 
      icon: <Monitor />, 
      title: 'Modern Frontend', 
      desc: 'React, Next.js, and TypeScript for creating interactive and fast user interfaces.',
      color: 'bg-red-500/10 text-red-500'
    },
    { 
      icon: <Database />, 
      title: 'Database Management', 
      desc: 'MongoDB and PostgreSQL for efficient data storage and real-time capabilities.',
      color: 'bg-red-500/10 text-red-500'
    },
    { 
      icon: <ShieldCheck />, 
      title: 'Security & Performance', 
      desc: 'Enterprise-grade security measures with performance optimization techniques.',
      color: 'bg-red-500/10 text-red-500'
    }
  ];

  const phases: PhaseCard[] = [
    { 
      title: "Discovery & Strategy", 
      items: ["Requirement Analysis", "Technology Stack", "Architecture Design", "Project Timeline"],
      index: 1
    },
    { 
      title: "Design & Development", 
      items: ["UI/UX Design", "Frontend Development", "Backend Development", "API Integration"],
      index: 2
    },
    { 
      title: "Testing & Launch", 
      items: ["Quality Assurance", "Performance Testing", "Security Audit", "Deployment & Launch"],
      index: 3
    }
  ];

  const services = [
    {
      title: "Custom Web Applications",
      description: "Tailor-made web solutions built with cutting-edge technology for your business needs.",
      icon: <Code size={24} />
    },
    {
      title: "E-commerce Platforms",
      description: "Secure online stores with payment gateways, inventory management, and analytics.",
      icon: <ShoppingBagIcon size={24} />
    },
    {
      title: "Progressive Web Apps",
      description: "Native-like web applications that work offline and can be installed on devices.",
      icon: <Cpu size={24} />
    }
  ];

  return (
    <motion.div 
      initial="hidden" 
      animate="visible" 
      variants={containerVariants} 
      className="bg-white dark:bg-gray-950 min-h-screen"
    >
      {/* Hero Section */}
      <section className="pt-20 pb-16 md:pt-24 md:pb-20">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 lg:gap-20 items-center">
            <motion.div variants={itemVariants} className="space-y-6">
              <div className="inline-flex items-center px-4 py-2 rounded-full bg-red-500/10 text-red-500 text-sm font-semibold border border-red-500/20">
                <Rocket size={16} className="mr-2" />
                Professional Web Development
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Build <span className="text-red-500">Powerful</span><br />
                Web Experiences
              </h1>
              
              <p className="text-gray-600 dark:text-gray-300 text-lg">
                We create high-performance, scalable web applications that drive business growth and deliver exceptional user experiences.
              </p>
              
              <div className="flex flex-wrap gap-4 items-center">
                <button 
                  className="px-7 py-3.5 bg-red-500 text-white rounded-xl font-bold text-base flex items-center hover:bg-red-600 transition-all hover:scale-105 group shadow-md"
                >
                  Start Your Project
                  <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={18} />
                </button>
                
                <motion.div 
                  animate={floatAnimation}
                  className="flex items-center space-x-3 p-4 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm"
                >
                  <div className="w-12 h-12 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center">
                    <Zap size={20} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Performance</p>
                    <p className="text-lg font-bold">99.9% Uptime</p>
                  </div>
                </motion.div>
              </div>

              <div className="flex gap-8 pt-6 border-t border-gray-100 dark:border-gray-800">
                <div className="text-center">
                  <p className="text-2xl font-bold text-red-500">200+</p>
                  <p className="text-sm text-gray-500 mt-1">Projects</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-red-500">50+</p>
                  <p className="text-sm text-gray-500 mt-1">Clients</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-red-500">24/7</p>
                  <p className="text-sm text-gray-500 mt-1">Support</p>
                </div>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="relative">
              <div className="relative w-full max-w-[520px] mx-auto bg-gradient-to-br from-gray-900 to-black rounded-2xl p-2 border-2 border-red-500/20 shadow-xl overflow-hidden">
                <div className="w-full bg-[#0a0a0a] p-5 font-mono text-sm leading-relaxed rounded-xl">
                  <div className="flex space-x-2 mb-4 border-b border-gray-800 pb-3">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    <span className="ml-3 text-gray-500 text-xs">app/page.tsx</span>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-purple-400">// Next.js 14 + TypeScript</p>
                    <p className="text-blue-400">export default function <span className="text-yellow-400">HomePage</span>() {'{'}</p>
                    <p className="pl-4 text-gray-400">return (</p>
                    <p className="pl-8 text-green-400">{'<'}<span className="text-cyan-400">WebApplication</span></p>
                    <p className="pl-12 text-gray-400">speed="⚡ 95+ Score"</p>
                    <p className="pl-12 text-gray-400">security="🔒 Enterprise"</p>
                    <p className="pl-8 text-green-400">/&gt;</p>
                    <p className="pl-4 text-gray-400">);</p>
                    <p className="text-blue-400">{'}'}</p>
                  </div>
                </div>
              </div>
              
              <div className="absolute -top-3 -right-3 w-14 h-14 bg-red-500/5 rounded-lg border border-red-500/10 flex items-center justify-center backdrop-blur-sm">
                <Code className="text-red-500" size={22} />
              </div>
              
              <div className="absolute -bottom-3 -left-3 w-12 h-12 bg-red-500/5 rounded-lg border border-red-500/10 flex items-center justify-center backdrop-blur-sm">
                <Cpu className="text-red-500" size={20} />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-14 bg-gray-50 dark:bg-gray-900/30">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-center mb-10"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-3">
              Our <span className="text-red-500">Services</span>
            </h2>
            <p className="text-gray-600 dark:text-gray-300 text-lg max-w-2xl mx-auto">
              Professional web development solutions tailored to your needs
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-8xl mx-auto">
            {services.map((service, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -5 }}
                className="bg-white dark:bg-gray-800 p-6 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm hover:shadow-md transition-all"
              >
                <div className="w-14 h-14 bg-red-500/10 rounded-xl flex items-center justify-center text-red-500 mb-4">
                  {service.icon}
                </div>
                <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                <p className="text-gray-600 dark:text-gray-300">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Technical Stack Section */}
      <section className="py-14">
        <div className="container mx-auto px-4 md:px-6">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-3xl md:text-4xl font-bold mb-10 text-center"
          >
            Our <span className="text-red-500">Expertise</span>
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -5 }}
                className="relative group"
              >
                <div className="relative p-6 space-y-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 h-full hover:shadow-md transition-all">
                  <div className="w-14 h-14 rounded-xl bg-red-500/10 flex items-center justify-center text-red-500">
                    {React.cloneElement(feature.icon, { size: 28 })}
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 dark:text-white">{feature.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Development Process */}
      <section className="py-14 bg-gray-50 dark:bg-gray-900/30">
        <div className="container mx-auto px-4 md:px-6">
          <motion.h2 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-3xl md:text-4xl font-bold mb-10 text-center"
          >
            Our <span className="text-red-500">Process</span>
          </motion.h2>
          
          <div className="max-w-8xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {phases.map((phase, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, x: i % 2 === 0 ? -25 : 25 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="relative"
                >
                  <div className="absolute -top-3 -right-3 w-10 h-10 bg-red-500 text-white rounded-full flex items-center justify-center text-2xl font-bold z-10">
                    {phase.index}
                  </div>
                  <div className="p-6 space-y-5 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 shadow-sm h-full">
                    <h3 className="text-3xl font-bold text-red-500">{phase.title}</h3>
                    <div className="space-y-3">
                      {phase.items.map((item, idx) => (
                        <div 
                          key={idx}
                          className="flex items-center space-x-3 p-3 rounded-lg hover:bg-red-50 dark:hover:bg-gray-700 transition-colors"
                        >
                          <div className="w-8 h-8 bg-red-500/10 rounded-lg flex items-center justify-center">
                            <CheckCircle2 size={16} className="text-red-500" />
                          </div>
                          <span className="text-xl text-gray-700 dark:text-gray-300">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section - 2 Columns */}
      <section className="py-14">
        <div className="container mx-auto px-4 md:px-6 max-w-8xl">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-3xl md:text-4xl font-bold mb-10 text-center"
          >
            Frequently Asked <span className="text-red-500">Questions</span>
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {faqs.map((faq, i) => (
              <motion.div 
                key={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.2 }}
                variants={i % 2 === 0 ? faqVariantsLeft : faqVariantsRight}
                transition={{ delay: i * 0.1 }}
                className="group"
              >
                <div className="p-6 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-red-500/30 transition-all shadow-sm hover:shadow-md h-full">
                  <h4 className="text-3xl mb-3 flex items-center">
                    <span className="w-10 h-10 rounded-full bg-red-500 text-white flex items-center justify-center mr-3 text-2xl">
                      Q
                    </span>
                    {faq.q}
                  </h4>
                  <p className="text-gray-600 dark:text-gray-300 pl-11 text-xl">
                    {faq.a}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <div className="container mx-auto px-4 md:px-6 pb-16 pt-10">
        <motion.div 
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-red-500 to-red-600"
        >
          <div className="relative p-8 md:p-10 text-white flex flex-col md:flex-row items-center justify-between text-center md:text-left gap-8">
            <div className="space-y-4 max-w-2xl">
              <h2 className="text-2xl md:text-4xl font-bold">
                Ready to <span className="text-black">Launch</span> Your Project?
              </h2>
              <p className="text-lg opacity-90">
                Let's build something extraordinary together. Contact us today for a free consultation.
              </p>
            </div>
            
            <button
              className="px-8 py-4 bg-black text-white rounded-xl font-bold text-lg hover:bg-gray-900 transition-all duration-300 hover:scale-105 min-w-[180px] shadow-lg"
            >
              Get Started
            </button>
          </div>
        </motion.div>

        {/* Footer */}
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-center mt-10 text-gray-600 dark:text-gray-400"
        >
          <p>© {new Date().getFullYear()} WebDev Solutions. All rights reserved.</p>
          <p className="mt-2 text-sm">Professional web development services</p>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default WebDevPage;