"use client";

import { motion } from 'framer-motion';
import { 
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  ArrowUp,
  Building,
  Code,
  Palette,
  Globe,
  Smartphone,
  Shield,
  FileText,
  Cookie,
  ChevronRight,
  Heart,
  Home,
  Briefcase,
  Users,
  Sparkles
} from 'lucide-react';
import Link from 'next/link';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const companyInfo = {
    name: "PMS Graphix",
    tagline: "Premium Digital Solutions",
    description: "We create exceptional digital experiences that drive business growth and user engagement.",
  };

  const navItems = [
    { 
      icon: Home, 
      name: "Home", 
      href: "/",
    },
    { 
      icon: Briefcase, 
      name: "Services", 
      href: "/service",
    },
    { 
      icon: Users, 
      name: "About", 
      href: "/about",
    },
    { 
      icon: Sparkles, 
      name: "Team", 
      href: "/team",
    }
  ];

  const services = [
    { icon: Code, label: "Custom Software", href: "/software" },
    { icon: Smartphone, label: "Mobile Applications", href: "appDevelopment" },
    { icon: Palette, label: "UI/UX Design", href: "/uiusdesign" },
    { icon: Globe, label: "Web Development", href: "/webDev" },
    { icon: Building, label: "Enterprise Solutions", href: "/aiSolution" },
  ];

  const contactInfo = [
    { icon: Mail, text: "contact@pmsgraphix.com", href: "mailto:contact@pmsgraphix.com" },
    { icon: Phone, text: "+92 (300) 123-4567", href: "tel:+923001234567" },
    { icon: MapPin, text: "Gulberg, Lahore, Pakistan", href: "#" },
  ];

  const legalLinks = [
    { icon: Shield, label: "Privacy Policy", href: "#" },
    { icon: FileText, label: "Terms of Service", href: "#" },
    { icon: Cookie, label: "Cookie Policy", href: "#" },
  ];

  const socialLinks = [
    { icon: Facebook, label: "Facebook", href: "#" },
    { icon: Twitter, label: "Twitter", href: "#" },
    { icon: Linkedin, label: "LinkedIn", href: "#" },
    { icon: Instagram, label: "Instagram", href: "#" },
  ];

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-200 border-t border-gray-100 dark:border-gray-800">
      {/* Main Footer Content */}
      <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Top Section - 4 Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          
          {/* Column 1 - Brand & Contact */}
          <div className="space-y-6">
            {/* Logo */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-red-500 to-red-600 flex items-center justify-center shadow-lg">
                  <Building className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{companyInfo.name}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{companyInfo.tagline}</p>
                </div>
              </div>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                {companyInfo.description}
              </p>
            </div>

            {/* Contact Info */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Contact Info</h4>
              <ul className="space-y-3">
                {contactInfo.map((contact, index) => (
                  <motion.li
                    key={contact.text}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <a
                      href={contact.href}
                      className="flex items-center gap-3 group"
                    >
                      <div className="w-10 h-10 rounded-lg bg-red-50 dark:bg-red-900/20 flex items-center justify-center group-hover:bg-red-100 dark:group-hover:bg-red-900/30 transition-colors">
                        <contact.icon className="w-5 h-5 text-red-500 dark:text-red-400" />
                      </div>
                      <span className="text-gray-700 dark:text-gray-300 group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors">
                        {contact.text}
                      </span>
                    </a>
                  </motion.li>
                ))}
              </ul>
            </div>
          </div>

          {/* Column 2 - Navigation Links */}
          <div>
            <div className="flex items-center gap-3 mb-6 pb-3 border-b border-gray-200 dark:border-gray-700">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Quick Navigation</h4>
            </div>
            <ul className="space-y-3">
              {navItems.map((item, index) => (
                <motion.li
                  key={item.name}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                >
                  <Link
                    href={item.href}
                    className="flex items-center gap-3 group p-3 rounded-lg hover:bg-red-50 dark:hover:bg-gray-800 transition-all duration-300"
                  >
                    <div className="w-10 h-10 rounded-lg bg-red-50 dark:bg-gray-800 flex items-center justify-center group-hover:bg-red-100 dark:group-hover:bg-gray-700">
                      <item.icon className="w-5 h-5 text-red-500 dark:text-red-400" />
                    </div>
                    <span className="text-gray-700 dark:text-gray-300 group-hover:text-red-600 dark:group-hover:text-red-400 font-medium">
                      {item.name}
                    </span>
                  </Link>
                </motion.li>
              ))}
            </ul>
          </div>

          {/* Column 3 - Services */}
          <div>
            <div className="flex items-center gap-3 mb-6 pb-3 border-b border-gray-200 dark:border-gray-700">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Our Services</h4>
            </div>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <motion.li
                  key={service.label}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                >
                  <Link
                    href={service.href}
                    className="flex items-center justify-between group p-3 rounded-lg hover:bg-red-50 dark:hover:bg-gray-800 transition-all duration-300"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-md bg-red-50 dark:bg-gray-800 flex items-center justify-center group-hover:bg-red-100 dark:group-hover:bg-gray-700">
                        <service.icon className="w-4 h-4 text-red-500 dark:text-red-400" />
                      </div>
                      <span className="text-gray-700 dark:text-gray-300 group-hover:text-red-600 dark:group-hover:text-red-400">
                        {service.label}
                      </span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400 dark:text-gray-500 group-hover:text-red-500 dark:group-hover:text-red-400 group-hover:translate-x-1 transition-all" />
                  </Link>
                </motion.li>
              ))}
            </ul>
          </div>

          {/* Column 4 - Newsletter */}
          <div>
            <div className="flex items-center gap-3 mb-6 pb-3 border-b border-gray-200 dark:border-gray-700">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Stay Updated</h4>
            </div>
            
            <div className="space-y-4 mb-8">
              <p className="text-gray-600 dark:text-gray-300">
                Subscribe to our newsletter for the latest updates and insights.
              </p>
              <div className="space-y-3">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-lg focus:outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100 dark:focus:ring-red-900/30 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                />
                <button className="w-full px-6 py-3 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-lg transition-colors shadow-md hover:shadow-lg">
                  Subscribe Now
                </button>
              </div>
            </div>

            {/* Social Media */}
            <div>
              <h5 className="font-semibold text-gray-900 dark:text-white mb-4">Follow Us</h5>
              <div className="flex gap-3">
                {socialLinks.map((social, index) => (
                  <motion.a
                    key={social.label}
                    href={social.href}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    whileHover={{ scale: 1.1, y: -3 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-12 h-12 rounded-xl bg-gray-50 dark:bg-gray-800 flex items-center justify-center hover:bg-red-50 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-700 hover:border-red-200 dark:hover:border-red-800 transition-all"
                    aria-label={social.label}
                  >
                    <social.icon className="w-5 h-5 text-gray-700 dark:text-gray-300 hover:text-red-500 dark:hover:text-red-400" />
                  </motion.a>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Middle Section - Legal & Certificate */}
        <div className="py-6 border-y border-gray-200 dark:border-gray-700 my-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Legal Links */}
            <div className="flex flex-wrap gap-6">
              {legalLinks.map((link, index) => (
                <motion.a
                  key={link.label}
                  href={link.href}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                >
                  <link.icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{link.label}</span>
                </motion.a>
              ))}
            </div>

            {/* Certifications */}
            <div className="flex items-center gap-4 text-sm">
              <div className="px-4 py-2 bg-gray-50 dark:bg-gray-800 rounded-lg text-gray-600 dark:text-gray-300">
                ISO 9001:2015 Certified
              </div>
              <div className="px-4 py-2 bg-gray-50 dark:bg-gray-800 rounded-lg text-gray-600 dark:text-gray-300">
                Member P@SHA
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Copyright */}
          <div className="text-center md:text-left">
            <p className="text-gray-600 dark:text-gray-400">
              © {currentYear} <span className="font-semibold text-gray-900 dark:text-white">PMS Graphix</span>. All rights reserved.
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
              Transforming businesses through innovative digital solutions since 2015.
            </p>
          </div>

          {/* Back to Top */}
          <motion.button
            onClick={scrollToTop}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 px-6 py-3 bg-red-500 hover:bg-red-600 text-white font-medium rounded-lg shadow-md hover:shadow-lg transition-all"
          >
            <ArrowUp className="w-5 h-5" />
            Back to Top
          </motion.button>

        </div>

        {/* Made with Love */}
        <div className="mt-8 pt-6 border-t border-gray-100 dark:border-gray-800 text-center">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="text-gray-500 dark:text-gray-400 flex items-center justify-center gap-2"
          >
            Made with
            <motion.span
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <Heart className="w-4 h-4 text-red-500 fill-red-500" />
            </motion.span>
            in Lahore, Pakistan
          </motion.p>
        </div>
      </div>
    </footer>
  );
}