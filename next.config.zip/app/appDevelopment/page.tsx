import AppDevPage from '@/app/src/modules/appPage/AppDevPage'


const Page = () => {
  return (
    <>
    <AppDevPage />
    </>
  )
}

export default Page