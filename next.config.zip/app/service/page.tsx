
import ServicesSection from '@/app/src/modules/servicePage/service'
import React from 'react'

const Page = () => {
  return (
    <>
    <ServicesSection />
    </>
  )
}

export default Page