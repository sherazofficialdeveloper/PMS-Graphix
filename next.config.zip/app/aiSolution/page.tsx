import AISolutionsPage from '@/app/src/modules/aiSolutionPage/AISolutionsPage'


const Page = () => {
  return (
    <>
    
    <AISolutionsPage />
    </>
  )
}

export default Page