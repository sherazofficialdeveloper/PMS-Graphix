import GraphicDesignPage from '@/app/src/modules/graphicPage/graphic'
import React from 'react'

const Page = () => {
  return (
    <>
    <GraphicDesignPage />
    </>
  )
}

export default Page