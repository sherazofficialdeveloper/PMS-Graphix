import Image from "next/image";
import Index from "./src/modules/homePage";

export default function Home() {
  return (
   <>
   <Index />
   </>
  );
}
