import WebDevPage from '@/app/src/modules/webPage/WebDevPage'
import React from 'react'

const Page = () => {
  return (
    <>
    <WebDevPage />
    </>
  )
}

export default Page