import DigitalMarketingPage from '@/app/src/modules/digitalPage/digital'
import React from 'react'

const Page = () => {
  return (
    <>
    <DigitalMarketingPage />
    </>
  )
}

export default Page