import UIUXPage from '@/app/src/modules/uiux/UIUXPage'
import React from 'react'

const Page = () => {
  return (
    <>
    <UIUXPage />
    </>
  )
}

export default Page