import SEOServicesPage from '@/app/src/modules/seoServicePage/seoService'
import React from 'react'

const Page = () => {
  return (
    <>
    <SEOServicesPage />
    </>
  )
}

export default Page