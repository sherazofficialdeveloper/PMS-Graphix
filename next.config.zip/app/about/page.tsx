import AboutPage from '@/app/src/modules/aboutPage/about'
import React from 'react'

const Page = () => {
  return (
    <>
    <AboutPage />
    </>
  )
}

export default Page