// app/layout.tsx
import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "./src/layout/header/headerTop"; // Yahan path sahi hai?
import FooterSection from "./src/layout/footer/footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "PMS GRAPHIX",
  description: "PMS Graphix – Your Complete Digital Solutions Partner PMS Graphix is a full-service software and digital solutions house, specializing in creating innovative and impactful online experiences. We provide end-to-end digital services, including custom web and app development, UI/UX design, graphic design, AI-powered solutions, software development, SEO optimization, and digital marketing. Our expert team combines creativity, technology, and strategy to deliver high-quality, scalable, and tailored solutions that drive business growth and maximize user engagemen",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
        <Navbar />
        <main className="min-h-screen">
          {children}
        </main>
        <FooterSection />
      </body>
    </html>
  );
}